# Offhand Screen View

Complemento para el mod **offhand** (fork de SFENCE / t-affeldt de `mcl_offhand`).
Si el mod base no está (o carga después), este mod lee la lista de inventario
`offhand` directamente y no se desactiva: ya no tira el error
*'offhand' mod not found, disabling*.
Muestra el item de la mano secundaria en pantalla, al estilo Minecraft,
**solo en primera persona**: al pasar a segunda/tercera persona el HUD se
oculta automáticamente (con el mod cliente incluido; ver más abajo) y en
tercera persona queda solo el item 3D del mod base en el brazo.

## El problema original

El icono viejo caía en `def.tiles[1]` y mostraba la textura del lado superior
**plana** (un `default:dirt_with_grass` se veía como un cuadrado de pasto),
mientras que en la mano principal el motor extruye un objeto 3D.

## Qué hace ahora

1. **Cubo 3D con movimiento.** Los bloques se dibujan con el modificador
   `[inventorycube` (el mismo renderizador 3D por software que usa el motor
   para el hotbar). Para que no parezca una imagen incrustada:
   - **gira** lentamente: se ciclan las cuatro rotaciones isométricas del cubo
     (`offhand_screen_spin`),
   - tiene una **sombra** suave detrás (`offhand_screen_shadow`),
   - **se balancea** al caminar (`offhand_screen_bob`).
2. **La mano del jugador (opcional), recortada de su skin.** Debajo del ítem
   puede dibujarse el brazo izquierdo del propio jugador (`offhand_screen_hand`,
   **apagado por defecto**): un único `[combine` con capas de texto plano
   recorta el brazo directo de la textura de skin (prueba los layouts 64x64 y
   64x32 a la vez: el que exista gana), se le aplica una máscara de sombreado
   (`textures/offhand_screen_view_hand_shade.png`) y queda como una tira
   **vertical** colgando del ancla del ítem. Funciona con cualquier skin y se
   reconstruye solo si el jugador se la cambia.
3. **Posición de mano izquierda.** El icono va anclado abajo a la izquierda,
   grande (380 px por defecto), **a la misma distancia del borde que la vista
   wield de la mano principal** (que está abajo a la derecha). La posición es
   una *fracción de pantalla* (`offhand_screen_x`, `offhand_screen_y`), así
   funciona en cualquier resolución.
4. **Contador de items** en la esquina, como en Minecraft.
5. Opcionalmente **esconde el icono del mod base** junto al hotbar
   (`offhand_screen_hide_base_icon`, apagado por defecto: los dos quedan
   visibles).
6. **Solo primera persona, automático.** El servidor no puede saber en qué
   cámara estás (`player:get_camera()` solo devuelve restricciones que pone el
   propio servidor), así que este repo trae un **mod cliente**
   (`clientmods/offhand_screen_view`) que lee `core.camera:get_camera_mode()`
   y le avisa al servidor por un *mod channel* (`"FP 0/1/2"`). Cuando el modo
   no es primera persona, el servidor elimina todos los elementos HUD del
   jugador; al volver a primera persona los recrea. Sin el mod cliente el
   icono se ve siempre (comportamiento anterior).
7. **Iluminación ambiental.** Los elementos de HUD no reciben la luz del mundo
   por sí solos, así que el mod muestrea la luz a la altura de los ojos del
   jugador (`minetest.get_node_light`) y oscurece ítem, mano y contador con
   `^[multiply` para que de noche o en una cueva no brillen a full
   (`offhand_screen_light`, activado por defecto).
8. **Solo texturas seguras para el motor.** Cada capa es UN elemento HUD:
   para el ítem solo se usan `[inventorycube` y cadenas secuenciales de
   `^[resize`/`^[multiply`/`^[opacity`, y para la mano un `[combine` con
   nombres de capa planos. Construcciones como `^[verticalframe` (que este
   mod usó antes para inclinar el ítem) el cliente real las renderiza como
   imágenes **estiradas**, así que fueron eliminadas por completo.

## Por qué no es un objeto 3D de verdad en primera persona

- El motor renderiza **un solo** modelo de mano en primera persona (la
  principal); una segunda mano real sigue abierta como pedido al motor
  ([luanti#10345](https://github.com/luanti-org/luanti/issues/10345)).
- El item 3D que el mod `offhand` adjunta al hueso `Arm_Left` no se dibuja en
  primera persona salvo con `forced_visible = true`, y aun así el cliente no
  aplica la transformación del hueso al jugador local: queda flotando a los
  pies. Por eso se usa un elemento de HUD anclado a la pantalla, que es lo
  único que puede quedar "a la altura de la mano".
- En **segunda/tercera persona** el mod base ya muestra el item 3D en el
  brazo, y el icono de este mod se oculta automáticamente gracias al mod
  cliente (instalación abajo).

## Ocultado automático: instalar el mod cliente

El servidor no tiene ninguna API para saber si estás en primera o tercera
persona; solo el cliente lo sabe. Por eso el ocultado automático necesita el
mod cliente que viene en `clientmods/`:

1. Copiá la carpeta `clientmods/offhand_screen_view` a la carpeta
   `clientmods` del juego (en Windows:
   `C:\Users\<tu_usuario>\AppData\minetest\clientmods\offhand_screen_view\`).
2. En `minetest.conf` agregá: `enable_client_modding = true`
3. En `AppData\minetest\clientmods\mods.conf` agregá:
   `load_mod_offhand_screen_view = true`
4. Del lado del servidor (o en el mismo `minetest.conf` en singleplayer):
   `enable_mod_channels = true`

Si no lo instalás, todo sigue funcionando igual pero el icono se ve en todas
las vistas. También podés desactivar el ocultado con
`offhand_screen_first_person_only = false`.

## Ajustes

| Ajuste | Por defecto | Descripción |
| --- | --- | --- |
| `offhand_screen_icon_size` | `380` | Tamaño del icono en píxeles. |
| `offhand_screen_bg_padding` | `6` | Píxeles de fondo oscuro (si está activo). |
| `offhand_screen_x` | `0.15` | Posición X, fracción del ancho (0..1). Renombrada de `..._pos_x` para que un valor viejo del `minetest.conf` no pise el default. |
| `offhand_screen_y` | `0.88` | Posición Y, fracción del alto (0..1). |
| `offhand_screen_show_icon` | `true` | Mostrar el icono de este mod. |
| `offhand_screen_first_person_only` | `true` | Ocultar el HUD fuera de primera persona (requiere el mod cliente). |
| `offhand_screen_show_background` | `false` | Fondo oscuro tipo ranura. |
| `offhand_screen_show_count` | `true` | Cantidad del stack en la esquina. |
| `offhand_screen_3d_icons` | `true` | Bloques como cubos 3D (si no, plano). |
| `offhand_screen_spin` | `true` | El cubo gira lentamente. |
| `offhand_screen_spin_period` | `1.6` | Segundos por vuelta completa. |
| `offhand_screen_shadow` | `true` | Sombra detrás del icono. |
| `offhand_screen_bob` | `true` | Balanceo al caminar. |
| `offhand_screen_hand` | `false` | Dibujar la mano del jugador bajo el ítem (opcional). |
| `offhand_screen_hand_skin_layout` | `0` | Recorte de skin: `0` auto, `64` o `32`. |
| `offhand_screen_hand_size` | `240` | Largo de la mano en píxeles. |
| `offhand_screen_light` | `true` | Oscurecer ítem/mano/contador según la luz ambiental. |
| `offhand_screen_hide_base_icon` | `false` | Esconder el icono del mod base. |

## API

```lua
offhand_screen_view.build_icon(itemname)         -- textura del primer frame
offhand_screen_view.build_icon_frames(itemname)  -- los 4 frames de rotación
offhand_screen_view.update(player)               -- refresca el HUD
offhand_screen_view.spin(player)                 -- avanza la rotación
offhand_screen_view.bob(player, clock)           -- aplica el balanceo
offhand_screen_view.hide_base_hud(player)        -- esconde el icono base
```

## Nota sobre el mod `offhand`

En el fork de **t-affeldt** la línea `textures:gsub("^%", "&")` usa un patrón
de Lua mal formado (`"^%"` en vez de `"%^"`) y lanza *malformed pattern*, por
lo que ahí el icono del mod base no llega a dibujarse para los bloques sin
`inventory_image`. En el fork de **SFENCE** está correcto. Este complemento no
depende de esa función: construye su propio icono.

## Tests

No hacen falta ni el motor ni un mundo: `tests/test_init.lua` carga el
`init.lua` real contra una API de `minetest`/`offhand` falsa y comprueba las
texturas generadas, los frames de rotación y los elementos HUD creados,
modificados y eliminados.

```sh
lua5.1 tests/test_init.lua     # o lua5.4, luajit, ...
```
