-- Tests for offhand_screen_view/init.lua
--
-- Runs the real init.lua against a minimal fake minetest/offhand API and checks
-- the textures it builds plus the HUD elements it creates/changes/removes.
--
-- Usage (from the mod folder):  lua5.1 tests/test_init.lua
-- No engine needed, only a Lua interpreter.

local test_path = (arg and arg[0]) or "tests/test_init.lua"
local mod_root = test_path:gsub("tests[/\\]test_init%.lua$", "")
if mod_root == "" then mod_root = "./" end

-- ==== tiny assert helpers ==========================================
local passed, failed = 0, 0

local function ok(cond, msg)
    if cond then
        passed = passed + 1
    else
        failed = failed + 1
        print("FAIL: " .. msg)
    end
end

local function eq(actual, expected, msg)
    if actual == expected then
        passed = passed + 1
    else
        failed = failed + 1
        print(string.format("FAIL: %s\n  expected: %s\n  actual:   %s",
            msg, tostring(expected), tostring(actual)))
    end
end

-- ==== fake environment =============================================
vector = {
    length = function(v)
        return math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
    end,
}

local overrides = {}
overrides["offhand_screen_icon_size"] = "64"      -- keep expectations simple
overrides["offhand_screen_show_background"] = true -- exercise the bg element
overrides["offhand_screen_hand"] = false -- the hand layer has its own section
overrides["offhand_screen_wield_view"] = false -- exact plain textures in most tests

minetest = {}

minetest.settings = {
    get = function(_, name)
        return overrides[name]
    end,
    get_bool = function(_, name)
        return overrides[name]
    end,
}

local logs = {}
function minetest.log(level, msg)
    table.insert(logs, level .. ": " .. msg)
end

-- ==== fake item/node definitions ===================================
minetest.registered_nodes = {
    -- cubic node, no icon: this is the case that used to show up flat
    ["default:dirt_with_grass"] = {
        type = "node",
        drawtype = "normal",
        tiles = {
            "default_grass.png",
            "default_dirt.png",
            "dt_px.png^default_grass_side.png",
            "dt_nx.png",
            "dt_pz.png^default_grass_side.png",
            "dt_nz.png",
        },
    },
    ["default:stone"] = {
        type = "node",
        drawtype = "normal",
        tiles = {"default_stone.png"},
    },
    ["default:bookshelf"] = {
        type = "node",
        drawtype = "normal",
        tiles = {"default_wood.png"},
        inventory_image = "default_bookshelf.png",
    },
    ["flowers:dandelion_white"] = {
        type = "node",
        drawtype = "plantlike",
        tiles = {"flowers_dandelion_white.png"},
    },
}

minetest.registered_items = {
    ["default:pick_steel"] = {
        type = "tool",
        inventory_image = "default_tool_steelpick.png",
        wield_image = "default_tool_steelpick.png",
    },
    ["default:apple"] = {
        type = "craftitem",
        inventory_image = "default_apple.png",
    },
    ["default:torch"] = {
        type = "node",
        drawtype = "torchlike",
        inventory_image = "default_torch_on_floor.png",
        tiles = {"default_torch_on_floor.png"},
    },
}
for name, def in pairs(minetest.registered_nodes) do
    minetest.registered_items[name] = def
end

-- same implementation as builtin/misc_helpers.lua
local inventorycube_calls = 0
minetest.inventorycube = function(top, left, right)
    inventorycube_calls = inventorycube_calls + 1
    return "[inventorycube{" .. (top:gsub("%^", "&")) ..
        "{" .. (left:gsub("%^", "&")) ..
        "{" .. (right:gsub("%^", "&"))
end

local on_joinplayer, on_leaveplayer, on_globalstep, after_cb, mods_loaded_cb
function minetest.register_on_joinplayer(f) on_joinplayer = f end
function minetest.register_on_leaveplayer(f) on_leaveplayer = f end
function minetest.register_globalstep(f) on_globalstep = f end
function minetest.after(_, f) after_cb = f end
function minetest.register_on_mods_loaded(f) mods_loaded_cb = f end

local players = {}
function minetest.get_connected_players() return players end

-- ambient light reported to the mod (15 = daylight)
local world_light = 15
function minetest.get_node_light(_) return world_light end
function minetest.get_player_by_name(name)
    for _, p in ipairs(players) do
        if p.pname == name and not p.left then return p end
    end
    return nil
end

-- ==== fake mod channel (client companion reports camera modes) =====
local joined_channels = {}
local modchannel_cb
function minetest.mod_channel_join(name)
    table.insert(joined_channels, name)
    return {
        is_writable = function() return true end,
        send_message = function() end,
        leave = function() end,
    }
end
function minetest.register_on_modchannel_message(f) modchannel_cb = f end
-- simulate the client-side companion mod reporting a camera mode
local function report(sender, mode)
    modchannel_cb("offhand_screen_view", sender, "FP " .. tostring(mode))
end

-- ==== fake offhand mod =============================================
local item_change_cb
offhand = {
    stacks = {},
    register_on_item_change = function(f) item_change_cb = f end,
}

local function ItemStack(name, count)
    return {
        name = name,
        count = count or 1,
        get_name = function(self) return self.name end,
        get_count = function(self) return self.count end,
    }
end

function offhand.get_offhand(player)
    return offhand.stacks[player:get_player_name()] or ItemStack("")
end

-- ==== fake player / HUD ============================================
local function new_player(name)
    local p = {
        pname = name,
        huds = {},
        ops = {},
        next_id = 1,
        velocity = {x = 0, y = 0, z = 0},
    }
    function p:get_player_name() return self.pname end
    function p:is_player() return true end
    function p:get_player_velocity() return self.velocity end
    p.inv = {
        sizes = {},
        stacks = {},
        get_size = function(self, list) return self.sizes[list] or 0 end,
        get_stack = function(self, list) return self.stacks[list] or ItemStack("") end,
    }
    function p:get_inventory() return self.inv end
    p.pos = {x = 0, y = 0, z = 0}
    function p:get_pos() return self.pos end
    p.props = {textures = {"character.png"}, eye_height = 1.625}
    function p:get_properties() return self.props end
    function p:hud_add(def)
        assert(def.hud_elem_type or def.type, "hud_add without element type")
        local id = self.next_id
        self.next_id = id + 1
        self.huds[id] = def
        table.insert(self.ops, {op = "add", id = id, def = def})
        return id
    end
    function p:hud_remove(id)
        assert(self.huds[id], "hud_remove of unknown id " .. tostring(id))
        self.huds[id] = nil
        table.insert(self.ops, {op = "remove", id = id})
    end
    function p:hud_change(id, stat, value)
        assert(self.huds[id], "hud_change of unknown id " .. tostring(id))
        self.huds[id][stat] = value
        table.insert(self.ops, {op = "change", id = id, stat = stat, value = value})
    end
    function p:count_huds()
        local n = 0
        for _ in pairs(self.huds) do n = n + 1 end
        return n
    end
    function p:find_hud(name)
        for id, def in pairs(self.huds) do
            if def.name == name then return id end
        end
        return nil
    end
    table.insert(players, p)
    return p
end

-- ==== load the mod =================================================
local function load_mod()
    local chunk, err = loadfile(mod_root .. "init.lua")
    assert(chunk, "cannot load init.lua: " .. tostring(err))
    local ok, err2 = pcall(chunk)
    assert(ok, "init.lua failed: " .. tostring(err2))
end
load_mod()

-- ==== build_icon / frames ==========================================
local build_icon = offhand_screen_view.build_icon
ok(build_icon ~= nil, "offhand_screen_view.build_icon is exported")
ok(offhand_screen_view.build_icon_frames ~= nil, "build_icon_frames is exported")

local px = "dt_px.png&default_grass_side.png"
local nx = "dt_nx.png"
local pz = "dt_pz.png&default_grass_side.png"
local nz = "dt_nz.png"
local frame1 = "[inventorycube{default_grass.png{" .. px .. "{" .. pz .. "^[resize:64x64"
local frame2 = "[inventorycube{default_grass.png{" .. pz .. "{" .. nx .. "^[resize:64x64"
local frame3 = "[inventorycube{default_grass.png{" .. nx .. "{" .. nz .. "^[resize:64x64"
local frame4 = "[inventorycube{default_grass.png{" .. nz .. "{" .. px .. "^[resize:64x64"

eq(build_icon("default:dirt_with_grass"), frame1,
    "cubic node is rendered as a 3D inventory cube")
ok(inventorycube_calls >= 1, "minetest.inventorycube() is used for escaping")

local frames = offhand_screen_view.build_icon_frames("default:dirt_with_grass")
eq(#frames, 4, "a cubic node gets the four rotation frames")
eq(frames[1], frame1, "frame 1 shows the +X/+Z sides")
eq(frames[2], frame2, "frame 2 is a 90 degree turn")
eq(frames[3], frame3, "frame 3 continues the turn")
eq(frames[4], frame4, "frame 4 closes the turn")

eq(#offhand_screen_view.build_icon_frames("default:pick_steel"), 1,
    "tools do not spin")
eq(build_icon("default:pick_steel"), "default_tool_steelpick.png^[resize:64x64",
    "wield_image is preferred for tools")
eq(build_icon("default:apple"), "default_apple.png^[resize:64x64",
    "craftitems use their inventory_image")
eq(build_icon("default:bookshelf"), "default_bookshelf.png^[resize:64x64",
    "inventory_image is used when the node defines one")
eq(build_icon("default:torch"), "default_torch_on_floor.png^[resize:64x64",
    "sprite drawtypes keep their inventory_image")
eq(build_icon("default:stone"),
    "[inventorycube{default_stone.png{default_stone.png{default_stone.png^[resize:64x64",
    "single tile is repeated on all cube faces")
eq(build_icon("some:unknown_item"), "unknown_item.png^[resize:64x64",
    "unknown items fall back to unknown_item.png")
eq(build_icon(""), nil, "empty itemname gives no icon")
eq(build_icon(nil), nil, "nil itemname gives no icon")

-- ==== HUD handling =================================================
local player = new_player("tester")
offhand_screen_view.update(player)
eq(player:count_huds(), 0, "no HUD while the offhand is empty")

offhand.stacks.tester = ItemStack("default:dirt_with_grass", 1)
item_change_cb(player, ItemStack(""), ItemStack("default:dirt_with_grass"))
eq(player:count_huds(), 3, "background + shadow + icon are added")

local icon_id = player:find_hud("offhand_screen_view_icon")
local bg_id = player:find_hud("offhand_screen_view_bg")
local shadow_id = player:find_hud("offhand_screen_view_shadow")
local count_id = player:find_hud("offhand_screen_view_count")
ok(icon_id ~= nil, "icon element exists")
ok(bg_id ~= nil, "background element exists (enabled for this test)")
ok(shadow_id ~= nil, "shadow element exists")
eq(count_id, nil, "no stack counter for a single item")
eq(player.huds[icon_id].text, frame1, "the HUD element carries the 3D cube texture")
eq(player.huds[shadow_id].text, frame1 .. "^[multiply:#000000^[opacity:90",
    "the shadow is a dark silhouette of the icon")
eq(player.huds[bg_id].text, "[fill:76x76:#00000066",
    "background is sized icon + padding")

local ops_before = #player.ops
offhand_screen_view.update(player)
eq(#player.ops, ops_before, "no HUD traffic when nothing changed")

-- the cube turns one frame per spin step
on_globalstep(0.41)
eq(player.huds[icon_id].text, frame2, "the cube turns on the spin timer")
eq(player.huds[shadow_id].text, frame2 .. "^[multiply:#000000^[opacity:90",
    "the shadow follows the turning cube")

-- stack size shows up as a counter
offhand.stacks.tester = ItemStack("default:dirt_with_grass", 5)
offhand_screen_view.update(player)
count_id = player:find_hud("offhand_screen_view_count")
ok(count_id ~= nil, "stack counter appears when the count grows")
eq(player.huds[count_id].text, "5", "stack counter shows the count")

-- swapping the item only updates the icon texture
offhand.stacks.tester = ItemStack("default:pick_steel", 1)
item_change_cb(player, ItemStack("default:dirt_with_grass"), ItemStack("default:pick_steel"))
eq(player.huds[icon_id].text, "default_tool_steelpick.png^[resize:64x64",
    "icon texture follows the new item")
eq(player:count_huds(), 3, "stack counter is gone again")

-- walking makes the icon sway (around its strip anchor offset)
player.velocity = {x = 4, y = 0, z = 0}
on_globalstep(0.11)
local off = player.huds[icon_id].offset
ok(off and (off.x ~= -32 or off.y ~= -32), "the icon bobs while walking")
player.velocity = {x = 0, y = 0, z = 0}
on_globalstep(0.11)
off = player.huds[icon_id].offset
ok(off and off.x == -32 and off.y == -32, "the icon settles when standing still")

-- emptying the offhand removes every element
offhand.stacks.tester = ItemStack("")
offhand_screen_view.update(player)
eq(player:count_huds(), 0, "all HUD elements are removed for an empty offhand")

-- a stack of blocks also gets a counter
local other = new_player("other")
offhand.stacks.other = ItemStack("default:stone", 3)
offhand_screen_view.update(other)
eq(other:count_huds(), 4, "background + shadow + icon + counter for a stack of blocks")

-- joining re-reads the offhand after the mod had time to set it up
local newcomer = new_player("newbie")
on_joinplayer(newcomer)
eq(newcomer:count_huds(), 0, "nothing is drawn before the delayed update runs")
offhand.stacks.newbie = ItemStack("default:apple", 2)
after_cb()
eq(newcomer:count_huds(), 4, "the delayed join update draws the icon")

-- leaving the game drops the stale HUD ids
on_leaveplayer(other)
for id in pairs(other.huds) do other.huds[id] = nil end
offhand_screen_view.update(other)
eq(other:count_huds(), 4, "a returning player gets fresh HUD elements")

-- ==== hiding the base offhand mod's icon ===========================
local base_ids = {slot = 10, item = 11, wear_bar = 12}
offhand[player] = {hud = base_ids}
for _, id in pairs(base_ids) do
    player.huds[id] = {name = "base", offset = {x = 0, y = 0}}
end

-- by default the base icon is left visible
offhand_screen_view.hide_base_hud(player)
eq(player.huds[11].offset.x, 0, "base icon stays visible by default")

-- enabling the setting parks every base element off-screen
overrides["offhand_screen_hide_base_icon"] = true
offhand_screen_view = nil
load_mod()
offhand_screen_view.hide_base_hud(player)
for key, id in pairs(base_ids) do
    eq(player.huds[id].offset.x, -100000, "base hud '" .. key .. "' parked offscreen")
end
overrides["offhand_screen_hide_base_icon"] = nil
offhand[player] = nil
offhand_screen_view = nil
load_mod()

-- ==== show_icon = false removes our HUD ============================
overrides["offhand_screen_show_icon"] = false
offhand_screen_view = nil
load_mod()
for id in pairs(player.huds) do player.huds[id] = nil end -- engine keeps HUDs across reloads; the fake does not
offhand.stacks.tester = ItemStack("default:stone", 1)
offhand_screen_view.update(player)
eq(player:count_huds(), 0, "no icon is drawn when show_icon is off")
overrides["offhand_screen_show_icon"] = nil
offhand_screen_view = nil
load_mod()

-- ==== first person only, driven by the client companion mod =======
offhand.stacks.tester = ItemStack("default:stone", 1)
offhand_screen_view.update(player)
eq(player:count_huds(), 3, "icon is visible before any camera report arrives")
ok(#joined_channels >= 1 and joined_channels[#joined_channels] == "offhand_screen_view",
    "the server joins the offhand_screen_view mod channel")

report("tester", 1) -- client switches to third person (back)
eq(player:count_huds(), 0, "HUD is torn down when third person is reported")

item_change_cb(player, ItemStack("default:stone"), ItemStack("default:apple"))
eq(player:count_huds(), 0, "changing the offhand while hidden stays hidden")

report("tester", 2) -- third person (front) is hidden too
eq(player:count_huds(), 0, "third-person-front keeps the HUD hidden")

report("tester", 0) -- back to first person
eq(player:count_huds(), 3, "the icon returns when first person is reported")

modchannel_cb("some_other_channel", "tester", "FP 1")
eq(player:count_huds(), 3, "messages on other channels are ignored")
modchannel_cb("offhand_screen_view", "", "FP 1")
eq(player:count_huds(), 3, "server-sent messages (empty sender) are ignored")
modchannel_cb("offhand_screen_view", "tester", "FP 9")
eq(player:count_huds(), 3, "out-of-range camera modes are ignored")
modchannel_cb("offhand_screen_view", "tester", "hello")
eq(player:count_huds(), 3, "malformed messages are ignored")

-- leaving the game forgets the reported mode
for id in pairs(other.huds) do other.huds[id] = nil end -- leftovers from before the module reloads
offhand_screen_view.update(other)
eq(other:count_huds(), 4, "second player draws icon + counter")
report("other", 1)
eq(other:count_huds(), 0, "third person hides a second player's icon as well")
on_leaveplayer(other)
other.left = true
for id in pairs(other.huds) do other.huds[id] = nil end
report("other", 0) -- stale report for somebody who is gone: must not crash
eq(other:count_huds(), 0, "no HUD is created for players who left")
other.left = nil

-- the whole feature can be switched off
overrides["offhand_screen_first_person_only"] = false
offhand_screen_view = nil
for id in pairs(player.huds) do player.huds[id] = nil end -- engine keeps HUDs across reloads; the fake does not
local joins_before = #joined_channels
load_mod()
eq(#joined_channels, joins_before, "no channel is joined when first_person_only is off")
offhand_screen_view.update(player)
eq(player:count_huds(), 3, "icon stays visible with first_person_only = false")
overrides["offhand_screen_first_person_only"] = nil
offhand_screen_view = nil
load_mod()

-- ==== hand layer cropped from the player skin =====================
overrides["offhand_screen_hand"] = true
offhand_screen_view = nil
for id in pairs(player.huds) do player.huds[id] = nil end -- engine keeps HUDs across reloads; the fake does not
load_mod()
offhand.stacks.tester = ItemStack("default:stone", 1)
offhand_screen_view.update(player)
local hand_id = player:find_hud("offhand_screen_view_hand")
ok(hand_id ~= nil, "the hand layer is drawn when enabled")
eq(player.huds[hand_id].text,
    "[combine:4x12:-44,-20=character.png:-36,-52=character.png"
        .. "^offhand_screen_view_hand_shade.png^[transformR270^[resize:240x80",
    "auto layout crops both arm variants, 64x64 winning on top")
eq(player:count_huds(), 4, "bg + hand + shadow + icon")

-- changing the skin rebuilds the hand on the next update
player.props.textures = {"fancy_skin.png"}
offhand_screen_view.update(player)
ok(player.huds[hand_id].text:find("fancy_skin", 1, true) ~= nil,
    "a skin change rebuilds the hand texture")
player.props.textures = {"character.png"}

-- old 64x32 skins: only the right-arm crop is used
overrides["offhand_screen_hand_skin_layout"] = 32
offhand_screen_view = nil
for id in pairs(player.huds) do player.huds[id] = nil end
load_mod()
offhand_screen_view.update(player)
hand_id = player:find_hud("offhand_screen_view_hand")
ok(player.huds[hand_id].text:find("[combine:4x12:-44,-20=", 1, true) ~= nil,
    "32-layout skins crop the right arm")
ok(player.huds[hand_id].text:find("-36,-52=", 1, true) == nil,
    "the 64x64 crop is skipped when layout 32 is forced")
overrides["offhand_screen_hand_skin_layout"] = nil
overrides["offhand_screen_hand"] = false
offhand_screen_view = nil
for id in pairs(player.huds) do player.huds[id] = nil end
load_mod()

-- ==== ambient light darkens the held item =========================
offhand.stacks.tester = ItemStack("default:stone", 3)
offhand_screen_view.update(player)
local licon = player:find_hud("offhand_screen_view_icon")
ok(player.huds[licon].text:find("multiply", 1, true) == nil,
    "daylight keeps the icon fully bright")

world_light = 0
offhand_screen_view.update(player)
ok(player.huds[licon].text:find("^[multiply:#000000", 1, true) ~= nil,
    "pitch darkness multiplies the icon by black")
local lcount = player:find_hud("offhand_screen_view_count")
eq(player.huds[lcount].number, 0x000000, "the stack counter darkens too")

world_light = 8
offhand_screen_view.update(player)
ok(player.huds[licon].text:find("^[multiply:#888888", 1, true) ~= nil,
    "a mid light level multiplies by mid gray")

on_globalstep(0.41)
ok(player.huds[licon].text:find("^[multiply:#888888", 1, true) ~= nil,
    "spinning frames keep the ambient-light modifier")

world_light = 15
offhand_screen_view.update(player)
ok(player.huds[licon].text:find("multiply", 1, true) == nil,
    "back to daylight removes the modifier")

-- ==== wield-view shear (left hand tilted like the main hand) ======
-- each strip is its own HUD element: ^[verticalframe stays OUTSIDE of any
-- ^[combine, the only form the engine's texture parser accepts
overrides["offhand_screen_wield_view"] = true
offhand_screen_view = nil
for id in pairs(player.huds) do player.huds[id] = nil end -- engine keeps HUDs across reloads; the fake does not
load_mod()
offhand.stacks.tester = ItemStack("default:stone", 1)
offhand_screen_view.update(player)

local icon_ids = {}
local shadow_n = 0
for id, def in pairs(player.huds) do
    if def.name == "offhand_screen_view_icon" then
        icon_ids[#icon_ids + 1] = id
    elseif def.name == "offhand_screen_view_shadow" then
        shadow_n = shadow_n + 1
    end
end
table.sort(icon_ids)
eq(#icon_ids, 10, "the sheared icon is drawn as 10 strip elements")
eq(shadow_n, 10, "the shadow is sheared in strips too")

local stone1 = "[inventorycube{default_stone.png{default_stone.png{default_stone.png^[resize:64x64"
local first = player.huds[icon_ids[1]]
local last = player.huds[icon_ids[10]]
eq(first.text, stone1 .. "^[verticalframe:10:0", "top strip of the icon")
ok(last.text:find("^[verticalframe:10:9", 1, true) ~= nil, "bottom strip of the icon")
eq(first.offset.x, -21, "the top strip leans toward the screen centre")
eq(last.offset.x, -43, "the bottom strip stays at the lower-left corner")
eq(first.offset.y, -32, "strips start at the top of the icon")

-- spinning keeps the shear
on_globalstep(0.41)
eq(player.huds[icon_ids[1]].text, stone1 .. "^[verticalframe:10:0",
    "spinning frames stay sheared")

overrides["offhand_screen_wield_view"] = false
offhand_screen_view = nil
for id in pairs(player.huds) do player.huds[id] = nil end
load_mod()

-- ==== fallback without minetest.inventorycube ======================
local saved = minetest.inventorycube
minetest.inventorycube = nil
offhand_screen_view = nil
load_mod()
eq(offhand_screen_view.build_icon("default:dirt_with_grass"), frame1,
    "manual caret escaping matches minetest.inventorycube()")
minetest.inventorycube = saved

-- ==== flat icons setting ==========================================
overrides["offhand_screen_3d_icons"] = false
offhand_screen_view = nil
load_mod()
eq(offhand_screen_view.build_icon("default:stone"), "default_stone.png^[resize:64x64",
    "3d icons can be turned off")
overrides["offhand_screen_3d_icons"] = nil

-- ==== default icon size ===========================================
overrides["offhand_screen_icon_size"] = nil
offhand_screen_view = nil
minetest.inventorycube = saved
load_mod()
eq(offhand_screen_view.build_icon("default:stone"),
    "[inventorycube{default_stone.png{default_stone.png{default_stone.png^[resize:380x380",
    "icons default to 380 px")

-- ==== fallback when the base offhand mod is absent ================
-- (this used to kill the whole mod with an error at startup)
offhand = nil
offhand_screen_view = nil
load_mod()

local solo = new_player("solo")
solo.inv.sizes.offhand = 1
solo.inv.stacks.offhand = ItemStack("default:stone", 2)
offhand_screen_view.update(solo)
eq(solo:count_huds(), 4, "the icon is drawn straight from the 'offhand' inventory list")

-- if the base mod shows up only after all mods are loaded, bind late
offhand = {
    stacks = {},
    get_offhand = function(p)
        return offhand.stacks[p:get_player_name()] or ItemStack("")
    end,
    register_on_item_change = function(f) item_change_cb = f end,
}
local cb_before = item_change_cb
if mods_loaded_cb then mods_loaded_cb() end
ok(item_change_cb ~= cb_before, "the base mod is bound when it appears at mods_loaded")
offhand.stacks.solo = ItemStack("default:apple", 1)
item_change_cb(solo, ItemStack(""), ItemStack("default:apple"))
local solo_icon = solo:find_hud("offhand_screen_view_icon")
eq(solo_icon and solo.huds[solo_icon].text or nil, "default_apple.png^[resize:380x380",
    "item changes flow through the late-bound callback")

-- leave the module in its default configuration
offhand_screen_view = nil
load_mod()

print(string.format("%d passed, %d failed", passed, failed))
if failed > 0 then os.exit(1) end
